var app = angular.module('myApp', []);
  
app.controller('SCartSellerLoginController',function($scope) {
  
  $scope.myusers=[{username:'user1',password:'12323'},
                {username:'user2',password:'12323'}];
  $scope.sellerSubmit=function()
  {
     if($scope.username && $scope.password)
     {
    var user=$scope.username;
    
    sessionStorage.setItem("username", user);
  
    //$scope.myusers.push({username:user,password:pass});
     }
	 //window.location.href="products1.html";
	 window.location.href="SCartSellerDashBoard.html";
  } 
    
  });