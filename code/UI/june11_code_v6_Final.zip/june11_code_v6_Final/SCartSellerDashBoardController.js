var app = angular.module('myApp', []);
  
app.controller('SCartSellerDashBoardController',function($scope,$http) {
   
   var username=sessionStorage.getItem("username");
   var MLWebServiceURL="";
   if(username==='store001')
   {
	   MLWebServiceURL="http://9.199.149.58:80/suggestions/bundles/STO.001";
   }
   else if(username==='store002')
   {
	   MLWebServiceURL="http://9.199.149.58:80/suggestions/bundles/STO.002";
   }
   else
   {
	   MLWebServiceURL="http://9.199.149.58:80/suggestions/bundles/STO.003";
   }
    
	//$http.get("http://dummy.restapiexample.com/api/v1/employees").then(
	$http.get(MLWebServiceURL).then(
	
      function successCallback(response) {
        $scope.response = response;
		
		$scope.bundles = response.data;
		
		var qty='';
		var items=[];
		var product='';
		var itemListVal='';
		
		var finalProducts=$scope.bundles.bundles;
			for ( var i in finalProducts) 
			{
				 qty = finalProducts[i].quantity;
				 
				 items = finalProducts[i].items;
				 itemListVal='';
					for ( var j in items) 
					{
						itemListVal=itemListVal+items[j]+',';
						
					}
					itemListVal=itemListVal.substring(0, itemListVal.length-1);
					
					$scope.bundles.bundles[i].itemListVal=itemListVal;
			}
			
			
			
      },
      function errorCallback(response) {
        console.log("Unable to perform get request");
      }
    );
	

  
  });