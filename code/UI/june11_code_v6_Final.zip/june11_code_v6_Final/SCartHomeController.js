 var app = angular.module('myApp', []);

app.controller('SCartHomeController',function($scope) {
  $scope.name = 'World';
   
  $scope.custLogin=function()
  {
	   	
	 window.location.href="SCartCutomerLogin.html";
  },
  $scope.sellerLogin=function()
  {
	   
	 window.location.href="SCartSellerLogin.html";
  }
});