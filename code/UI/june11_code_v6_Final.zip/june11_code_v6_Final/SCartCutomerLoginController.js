var app = angular.module('myApp', []);

app.controller('SCartCutomerLoginController',function($scope) {
  
  $scope.myusers=[{username:'user1',password:'12323'},
                {username:'user2',password:'12323'}];
  $scope.custSubmit=function()
  {
     if($scope.username && $scope.password)
     {
    var user=$scope.username;
    var pass=$scope.password;
    
  
    //$scope.myusers.push({username:user,password:pass});
     }
	 
	 window.location.href="productList.html";
  } 
  
 
});