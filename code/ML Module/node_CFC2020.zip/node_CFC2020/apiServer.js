// First add the obligatory web framework --
var express = require('express');
var app = express();
var bodyParser = require('body-parser');

var url = require('url');

app.use(bodyParser.urlencoded({
  extended: true
}));
app.use(bodyParser.json());

var cors = require('cors');

// use it before all route definitions
app.use(cors({origin: '*'}));

// get our app functions
var functions = require('./functions.js');

// API: for fetching product bundling solutions for a particular store
// URL Paramaters: storeId
app.get('/suggestions/bundles/:storeId', function(request, response) {
  console.log("Request came from IP: "+ request.connection.remoteAddress);  
    if (request.params.storeId) {
		functions.readProdBundlingSolutions(request.params.storeId,function(responseDOC){
            if(responseDOC != null)
				response.send(responseDOC);
            else{
                response.status(500);
	            response.send("API server has encountered an error");
            }
        });
    }
    else{
	    response.status(400);
	    response.send("Bad Request: Please check the parameters passed");
    }
});

// API: for fetching product recommendations across all stores data
// URL Paramaters: itemId
// eg: http://9.199.149.58/suggestions/products/Milk
app.get('/suggestions/products/:itemId', function(request, response) {
  console.log("Request came from IP: "+ request.connection.remoteAddress);  
    if (request.params.itemId) {
		functions.readProdRecommendations(request.params.itemId,function(responseDOC){
            if(responseDOC != null)
				response.send(responseDOC);
            else{
                response.status(500);
	            response.send("API server has encountered an error");
            }
        });
    }
    else{
	    response.status(400);
	    response.send("Bad Request: Please check the parameters passed");
    }
});

// API: dummy endpoint exposed to emulate stock pile up detection in UI
// URL Paramaters: itemId
// eg: http://9.199.149.58/check/products/Milk
app.get('/check/products/:itemId', function(request, response) {
  console.log("Request came from IP: "+ request.connection.remoteAddress);  
    if (request.params.itemId) {
		functions.checkProductQtyLimit(request.params.itemId,function(responseDOC){
            if(responseDOC != null)
				response.send(responseDOC);
            else{
                response.status(500);
	            response.send("API server has encountered an error");
            }
        });
    }
    else{
	    response.status(400);
	    response.send("Bad Request: Please check the parameters passed");
    }
});

// test endpoint
app.get('/', function(request, response) {
	response.send("Hello there, Welcome to CFC 2020");
});

// Now we go and listen for a connection.
app.listen(80, '0.0.0.0', function() {
  // print a message when the server starts listening
  console.log("server starting on 80");
});