'use strict'
const fs = require('fs');

/* test function */
function getOrderDetails (orderType,orderID,callback) {
    var finalJSONString = "{\"testId\": \"" + orderID + "\"}";
	finalJSON = JSON.parse(finalJSONString);
    callback(finalJSON);
}

/* function: read product bundling solutions from data store */
function readProdBundlingSolutions(storeId,callback)
{
  fs.readFile('inputFiles/prodBundlingSolutions.csv', 'utf8', function (err, data) {

	var bundleSolnObj = {
		"bundles": [
			{"quantity": 7, "items": ["item1"]},
		]
	};

	/*
	 * csv data file: [storeId], [quantity], [item], [item] ..
	 * sample data line: STO.001, 5, item01, item02,..
	 * number of items to be bundled will vary
	*/
	var dataArray = data.split(/\r?\n/);
	
	var currBundleSoln = bundleSolnObj
	
	var currBundle;
	var i,j;
	var recordsCounter=0
	for(i=0; i<dataArray.length; i++)
	{	
		if(0 < dataArray[i].length)
		{
			var lineData = dataArray[i].split(',')
			
			// check if storeId matches
			if(storeId == lineData[0])
			{
				// reset bundleObj to default template
				var bundleObj = {
					"quantity": 9,
					"items": ["item4"]
				};
				
				currBundle = bundleObj
				
				// lineData[n] is quantity - last element in the list
				currBundle.quantity = lineData[(lineData.length)-1]
				
				for(j=1; j<(lineData.length-1); j++)
				{
					currBundle.items[j-1] = lineData[j]
				}
				currBundleSoln.bundles[recordsCounter] = currBundle
				recordsCounter=recordsCounter+1
			}
		}
	}

	// return 
	if(recordsCounter == 0)
	{
		currBundleSoln = {"bundles": []}
	}

	//console.log("final bundling solution")
	//console.log(JSON.stringify(currBundleSoln))
    callback(currBundleSoln);
  });
}

/* readProdRecommendations */
/* function: read product bundling solutions from data store */
function readProdRecommendations(itemId,callback)
{
  fs.readFile('inputFiles/prodRecommendations.csv', 'utf8', function (err, data) {
	var prodRecObj = {
		"items": ["item1"]
	};

	/*
	 * csv data file: [item],[item],[item] ..
	 * sample data line: item01,item02,item03..
	 * first item is the antecedent item
	 * rest of the items in the data line are consequents for the antecedent item
	*/
	var dataArray = data.split(/\r?\n/);
	
	var currProdRec = prodRecObj
	
	var i,j;
	var recordsCounter=0
	for(i=0; i<dataArray.length; i++)
	{	
		if(0 < dataArray[i].length)
		{
			var lineData = dataArray[i].split(',')
			// check if itemId matches
			if(itemId == lineData[0])
			{
				for(j=1; j<lineData.length; j++)
				{
					currProdRec.items[j-1] = lineData[j]
				}
				recordsCounter=recordsCounter+1

				//one itemId will have one entry in the data file. Break from loop once a solution is found
				break;
			}
		}
	}

	// return 
	if(recordsCounter == 0)
	{
		currProdRec = {"items": []}
	}

	//console.log("final product recommendations")
	//console.log(JSON.stringify(currProdRec))
    callback(currProdRec);
  });
}

/* checkQtyLimitForProducts */
/* function: read product qty limits from data store */
function checkProductQtyLimit(itemId,callback)
{
  fs.readFile('inputFiles/prodQtyLimits.csv', 'utf8', function (err, data) {
  
  var prodQtyLimitObj = {"qty": -1};
	/*
	 * csv data file: item,qty ..
	 * sample data line: Milk,5
	*/
	var dataArray = data.split(/\r?\n/);
	
	var currProdQty = prodQtyLimitObj
	
	var i;
	var recordsCounter=0
	for(i=0; i<dataArray.length; i++)
	{	
		if(0 < dataArray[i].length)
		{
			var lineData = dataArray[i].split(',')
			
			// check if itemId matches
			if(itemId == lineData[0])
			{
				currProdQty.qty = lineData[1]
			}
		}
	}
	
	//console.log("final product recommendations")
	//console.log(JSON.stringify(currProdQty))
    callback(currProdQty);
  });
}

module.exports = {
	getOrderDetails: getOrderDetails,
	readProdBundlingSolutions: readProdBundlingSolutions,
	readProdRecommendations: readProdRecommendations,
	checkProductQtyLimit: checkProductQtyLimit
}
