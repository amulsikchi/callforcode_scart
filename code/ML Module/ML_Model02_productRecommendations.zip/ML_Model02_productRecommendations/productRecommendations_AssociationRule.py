#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import numpy as np
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

# read the transactions
transactionAllStores = pd.read_csv("transactions.csv")

print("Begin: Preparing product recommendations by learning order history data across all stores")

# get items for each order across all stores
## data model is defined to have items after the store column (2nd column)
## skip first two columns and read the items alone for the analysis
currStoreItems = transactionAllStores.iloc[:,2:5]

# remove columns with NaN values
i = 0
records = []
while (i<(currStoreItems.size/len(currStoreItems.columns))):
    trans = [str(currStoreItems.values[i,j]) for j in range(0,(len(currStoreItems.columns)))]
    trans = [x for x in trans if str(x) != 'nan'] # trim our NaN
    records.append(trans)
    i=i+1

# convert the above list of data to a sparse matrix
te = TransactionEncoder()
recordsSpMtx = te.fit(records).transform(records, sparse=True)

sparse_df = pd.SparseDataFrame(recordsSpMtx, columns=te.columns_, default_fill_value=0)
sparse_df.head()
#print(sparse_df.shape)

frequent_itemsets = apriori(sparse_df, min_support=0.001, use_colnames=True, verbose=1)
#print(frequent_itemsets)

rules = association_rules(frequent_itemsets, min_threshold=0.01, metric="confidence")
#print(rules.shape)

rules = rules.sort_values(by="confidence", ascending=False)
#rules

# filter the dataset
## confidence of atleast 50% (0.5), lift > 1 and min support of atleast 20%(0.2)
prodAssociationList = rules[ (rules['lift'] > 1) & (rules['confidence'] >= 0.5) & (rules['support'] >= 0.2) ]

# get list of antecedants (limited to length 1 to suit the UI calls for the current implementation)
i=0
antecedants = []
while(i<len(prodAssociationList)):
    listAntecedents = list(prodAssociationList['antecedents'].values[i])
    if(len(listAntecedents)==1):
        antecedants.append(listAntecedents[0])
    #increment i
    i += 1
antecedants = list(dict.fromkeys(antecedants))

# write to output csv file!
prodRecommendsFile = open("prodRecommendations.csv", 'w+')
firstEntryToFile=0

# prepare list of bundles for the store
i=0
while(i<len(antecedants)):
    consequents = []
    print(">> Antecedant: " + antecedants[i])
    
    j=0
    while(j<len(prodAssociationList)):
        listAntecedents = list(prodAssociationList['antecedents'].values[j])
        if(len(listAntecedents)==1 and (listAntecedents[0]==antecedants[i])):
            listConsequents = list(prodAssociationList['consequents'].values[j])
            for consequent in listConsequents:
                consequents.append(consequent)
            #print(str(antecedants[i]) + "->" + str(listConsequents))
        #increment i
        j += 1
    # remove duplicates
    consequents = list(dict.fromkeys(consequents))
    
    # write to prodRecommendations output file
    if(firstEntryToFile==1):
        prodRecommendsFile.write("\n")
    else:
        firstEntryToFile=1
    prodRecommendsFile.write(antecedants[i])
    for consequent in consequents:
        prodRecommendsFile.write(",")
        prodRecommendsFile.write(consequent)
    print(consequents)
    #increment i
    i += 1

# close file
prodRecommendsFile.close()