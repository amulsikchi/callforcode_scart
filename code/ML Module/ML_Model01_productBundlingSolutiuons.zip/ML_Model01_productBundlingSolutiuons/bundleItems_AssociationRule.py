#!/usr/bin/env python
# coding: utf-8

import pandas as pd
import numpy as np
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori
from mlxtend.frequent_patterns import association_rules

# read the transactions
transaction = pd.read_csv("transactions.csv")

# get the list of stores in the transaction data
storesList = transaction['STORE_ID']
storeList = list(dict.fromkeys(storesList))

# write to output csv file!
bundleListFile = open("prodBundlingSolutions.csv", 'w+')
firstEntryToFile=0

for store in storeList:
    print("Begin: Processing bundling solutions for " + store)
    currStoreTrans = transaction.loc[transaction['STORE_ID'] == store]
    #print(currStoreTrans)
    
    # get items for each order for the particular store
    ## data model is defined to have items after the store column
    ## skip first two columns and read the items alone for the analysis
    currStoreItems = currStoreTrans.iloc[:,2:5]
    #print(currStoreItems)
    
    # remove columns with NaN values
    i = 0
    records = []
    while (i<(currStoreItems.size/len(currStoreItems.columns))):
        trans = [str(currStoreItems.values[i,j]) for j in range(0,(len(currStoreItems.columns)))]
        trans = [x for x in trans if str(x) != 'nan'] # trim our NaN
        records.append(trans)
        i=i+1
    
    #print(records)
    
    # convert the above list of data to a sparse matrix
    te = TransactionEncoder()
    recordsSpMtx = te.fit(records).transform(records, sparse=True)
    
    sparse_df = pd.SparseDataFrame(recordsSpMtx, columns=te.columns_, default_fill_value=0)
    sparse_df.head()
    #print(sparse_df.shape)

    frequent_itemsets = apriori(sparse_df, min_support=0.001, use_colnames=True, verbose=1)
    #print(frequent_itemsets)
    
    rules = association_rules(frequent_itemsets, min_threshold=0.01, metric="confidence")
    #print(rules.shape)

    rules = rules.sort_values(by="confidence", ascending=False)
    
    # filter the dataset
    ## confidence of atleast 50% (0.5), lift > 1 and support of atleast 20%(0.2)
    prodAssociationList = rules[ (rules['lift'] > 1) & (rules['confidence'] >= 0.5) & (rules['support'] >= 0.2) ]
    #print(prodAssociationList)
    
    # prepare list of bundles for the store
    i=0
    listProductBundle = []
    while(i<len(prodAssociationList)):
        currProductBundle = []
        listAntecedents = list(prodAssociationList['antecedents'].values[i])
        listConsequents = list(prodAssociationList['consequents'].values[i])
        for antecedent in listAntecedents:
            currProductBundle.append(antecedent)
        for consequent in listConsequents:
            currProductBundle.append(consequent)
        # sort the list before appending to the list of productBundles
        currProductBundle.sort()
        #print(currProductBundle)
    
        # append to the list of product bundles
        listProductBundle.append(currProductBundle)
    
        # increment i
        i += 1

    # Initialize dict
    dictProductBundle = {} 

    # Using Iteration 
    for prodBundle in listProductBundle: 
        dictProductBundle.setdefault(tuple(prodBundle), list()).append(1)
    
    for a, b in dictProductBundle.items(): 
        dictProductBundle[a] = sum(b) 

    # Printing output 
    dictProductBundle.items()

    print("End: "+ str(len(dictProductBundle)) + " different types of product bundles to be prepared for " + store + ": " + str(dictProductBundle))
    
    # write to out csv ["STORE_ID","ITEM1"...]
    for keys in dictProductBundle:
        if(firstEntryToFile==1):
            bundleListFile.write("\n")
        else:
            firstEntryToFile=1
        bundleListFile.write(store)
        for key in keys:
            bundleListFile.write(",")
            bundleListFile.write(key)
        # currently model has just one logic to learn the quanity to be prepared
        ## min of 5 bundles to be prepared 
        ### also factor in the frequency of the combination of items in the rules. Say freq=2 => 5*2 = 10 bundles
        bundleListFile.write(",")
        currQty = int(dictProductBundle[keys])*5
        bundleListFile.write(str(currQty))
        
# close file
bundleListFile.close()

